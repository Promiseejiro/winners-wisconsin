"use client";
import { motion, Variants } from "framer-motion";
import Image from "next/image";
import content from "@/content/home.json";
import { useChurchSettings } from "@/providers/church-settings-provider";

const fadeInLeft: Variants = {
  hidden: { opacity: 0, x: -60 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.8, ease: "easeOut" } },
};

const fadeInRight: Variants = {
  hidden: { opacity: 0, x: 60 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.8, ease: "easeOut" } },
};

const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
};

const ResidentPastor = () => {
  const { settings } = useChurchSettings();
  const pastor = {
    label: settings.pastorTitle || content.pastor.label,
    name: settings.pastorName || content.pastor.name,
    description: settings.pastorBiography || content.pastor.description,
  };
  const pastorImage = settings.pastorImage || (content as any).pastor?.image || "";

  return (
    <section className="py-[80px] bg-primary">
      <div className="container">
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={staggerContainer}
        >
          <motion.div variants={fadeInLeft} className="relative">
            <div className="relative rounded-lg overflow-hidden shadow-xl">
              {pastorImage ? (
                <Image
                  src={pastorImage}
                  alt={pastor.name}
                  width={600}
                  height={700}
                  unoptimized
                  className="object-cover w-full h-[500px]"
                />
              ) : (
                <div className="flex h-[500px] w-full items-center justify-center bg-white/10 text-center text-white/80">
                  <span>Upload the resident pastor’s photograph in the CMS.</span>
                </div>
              )}
            </div>
          </motion.div>

          <motion.div variants={fadeInRight}>
            <div className=" dark font-semibold text-sm uppercase tracking-[1px] mb-2">
              {pastor.label}
            </div>
            <h2 className="font-cormorant text-4xl sm:text-5xl font-bold text-white mb-6">
              {pastor.name}
            </h2>
            <p className="text-white leading-relaxed text-base mb-6">{pastor.description}</p>

          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default ResidentPastor;
